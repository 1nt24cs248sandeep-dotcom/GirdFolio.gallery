package com.gridfolio.app.models;

public class User {
    public String uid;
    public String displayName;
    public String email;
    public String photoUrl;
    public String planTier;
    public long createdAt;

    public User() {}

    public User(String uid, String displayName, String email, String photoUrl) {
        this.uid = uid;
        this.displayName = displayName;
        this.email = email;
        this.photoUrl = photoUrl;
        this.planTier = "free";
        this.createdAt = System.currentTimeMillis();
    }
}
