package com.gridfolio.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.gridfolio.app.R;
import com.gridfolio.app.models.Gallery;

import java.util.ArrayList;
import java.util.List;

public class AlbumAdapter extends RecyclerView.Adapter<AlbumAdapter.VH> {

    private final List<Gallery> items = new ArrayList<>();

    public void submit(List<Gallery> next) {
        items.clear(); items.addAll(next); notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int v) {
        View view = LayoutInflater.from(p.getContext()).inflate(R.layout.item_album, p, false);
        return new VH(view);
    }
    @Override public void onBindViewHolder(@NonNull VH h, int i) {
        h.title.setText(items.get(i).name);
    }
    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView title;
        VH(@NonNull View v) { super(v); title = v.findViewById(R.id.album_title); }
    }
}
