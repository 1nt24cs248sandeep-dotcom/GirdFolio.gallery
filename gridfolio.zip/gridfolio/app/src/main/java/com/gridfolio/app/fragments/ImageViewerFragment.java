package com.gridfolio.app.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.gridfolio.app.R;
import com.gridfolio.app.adapters.ImagePagerAdapter;
import com.gridfolio.app.models.ImageItem;

import java.util.ArrayList;
import java.util.List;

public class ImageViewerFragment extends Fragment {
    private List<ImageItem> items = new ArrayList<>();
    private int startIndex = 0;

    public void setData(List<ImageItem> items, int startIndex) {
        this.items = items; this.startIndex = startIndex;
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_image_viewer, c, false);
    }

    @Override public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        ViewPager2 pager = v.findViewById(R.id.pager);
        pager.setAdapter(new ImagePagerAdapter(items));
        pager.setCurrentItem(startIndex, false);
    }
}
