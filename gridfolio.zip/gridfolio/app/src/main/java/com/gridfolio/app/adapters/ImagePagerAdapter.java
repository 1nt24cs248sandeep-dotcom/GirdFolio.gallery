package com.gridfolio.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.github.chrisbanes.photoview.PhotoView;
import com.gridfolio.app.models.ImageItem;

import java.util.List;

public class ImagePagerAdapter extends RecyclerView.Adapter<ImagePagerAdapter.VH> {
    private final List<ImageItem> items;
    public ImagePagerAdapter(List<ImageItem> items) { this.items = items; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        FrameLayout fl = new FrameLayout(parent.getContext());
        fl.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        PhotoView pv = new PhotoView(parent.getContext());
        pv.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        fl.addView(pv);
        return new VH(fl, pv);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int i) {
        Glide.with(h.itemView.getContext()).load(items.get(i).storageUrl).into(h.photo);
    }
    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        PhotoView photo;
        VH(@NonNull View v, PhotoView p) { super(v); this.photo = p; }
    }
}
