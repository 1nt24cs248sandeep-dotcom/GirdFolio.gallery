package com.gridfolio.app.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.gridfolio.app.R;
import com.gridfolio.app.adapters.AlbumAdapter;
import com.gridfolio.app.models.Gallery;
import com.gridfolio.app.repositories.GalleryRepository;

import java.util.ArrayList;
import java.util.List;

public class AlbumsFragment extends Fragment {
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_albums, c, false);
    }
    @Override public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        RecyclerView r = v.findViewById(R.id.recycler);
        r.setLayoutManager(new LinearLayoutManager(getContext()));
        AlbumAdapter a = new AlbumAdapter();
        r.setAdapter(a);

        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) return;
        new GalleryRepository().listForUser(uid).addOnSuccessListener(snap -> {
            List<Gallery> list = new ArrayList<>();
            snap.forEach(d -> { Gallery g = d.toObject(Gallery.class); g.id = d.getId(); list.add(g); });
            a.submit(list);
        });
    }
}
