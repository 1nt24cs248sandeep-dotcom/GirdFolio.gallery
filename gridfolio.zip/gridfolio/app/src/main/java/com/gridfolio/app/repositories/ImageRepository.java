package com.gridfolio.app.repositories;

import android.net.Uri;

import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.gridfolio.app.models.ImageItem;

public class ImageRepository {
    private final CollectionReference col =
            FirebaseFirestore.getInstance().collection("images");
    private final StorageReference storage =
            FirebaseStorage.getInstance().getReference("images");

    public UploadTask uploadFile(String uid, String fileName, Uri data) {
        return storage.child(uid).child(fileName).putFile(data);
    }

    public Task<DocumentReference> addMetadata(ImageItem item) { return col.add(item); }
    public Task<Void> delete(String id) { return col.document(id).delete(); }

    public Task<QuerySnapshot> listForGallery(String galleryId) {
        return col.whereEqualTo("galleryId", galleryId)
                .orderBy("sortOrder", Query.Direction.ASCENDING)
                .limit(20)
                .get();
    }

    public Query realtimeForUser(String uid) {
        return col.whereEqualTo("userId", uid)
                .orderBy("createdAt", Query.Direction.DESCENDING);
    }
}
