package com.gridfolio.app.viewmodels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.gridfolio.app.models.ImageItem;
import com.gridfolio.app.repositories.ImageRepository;

import java.util.ArrayList;
import java.util.List;

public class HomeViewModel extends ViewModel {
    private final ImageRepository repo = new ImageRepository();
    private final MutableLiveData<List<ImageItem>> images = new MutableLiveData<>(new ArrayList<>());

    public LiveData<List<ImageItem>> getImages() { return images; }

    public void load() {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) return;
        repo.realtimeForUser(uid).addSnapshotListener((snap, e) -> {
            if (snap == null) return;
            List<ImageItem> list = new ArrayList<>();
            snap.forEach(d -> {
                ImageItem it = d.toObject(ImageItem.class);
                it.id = d.getId();
                list.add(it);
            });
            images.setValue(list);
        });
    }
}
