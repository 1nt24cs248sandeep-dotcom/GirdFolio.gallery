package com.gridfolio.app.utils;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class FileUtils {

    public static File exportAlbumZip(Context ctx, String albumName, List<File> files) throws Exception {
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!dir.exists()) dir.mkdirs();
        File out = new File(dir, albumName + ".zip");
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(out))) {
            byte[] buf = new byte[8192];
            for (File f : files) {
                zos.putNextEntry(new ZipEntry(f.getName()));
                try (InputStream in = new java.io.FileInputStream(f)) {
                    int n;
                    while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
                }
                zos.closeEntry();
            }
        }
        return out;
    }

    public static File copyUriToCache(Context ctx, Uri uri, String name) throws Exception {
        File f = new File(ctx.getCacheDir(), name);
        ContentResolver cr = ctx.getContentResolver();
        try (InputStream in = cr.openInputStream(uri); OutputStream out = new FileOutputStream(f)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        return f;
    }
}
