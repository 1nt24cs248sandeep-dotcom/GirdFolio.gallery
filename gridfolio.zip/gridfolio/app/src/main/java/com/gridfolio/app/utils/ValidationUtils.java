package com.gridfolio.app.utils;

import android.util.Patterns;

public class ValidationUtils {
    public static boolean isValidEmail(String s) {
        return s != null && Patterns.EMAIL_ADDRESS.matcher(s).matches();
    }
    public static boolean isValidPassword(String s) {
        if (s == null || s.length() < 8) return false;
        boolean hasDigit = false;
        for (char c : s.toCharArray()) if (Character.isDigit(c)) { hasDigit = true; break; }
        return hasDigit;
    }
    public static boolean isValidDisplayName(String s) {
        return s != null && s.length() >= 2 && s.length() <= 40;
    }
}
