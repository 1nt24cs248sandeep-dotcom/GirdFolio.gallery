package com.gridfolio.app.models;

public class Gallery {
    public String id;
    public String userId;
    public String name;
    public String layoutType; // "grid" | "staggered"
    public boolean isPublic;
    public long createdAt;

    public Gallery() {}

    public Gallery(String userId, String name) {
        this.userId = userId;
        this.name = name;
        this.layoutType = "grid";
        this.isPublic = false;
        this.createdAt = System.currentTimeMillis();
    }
}
