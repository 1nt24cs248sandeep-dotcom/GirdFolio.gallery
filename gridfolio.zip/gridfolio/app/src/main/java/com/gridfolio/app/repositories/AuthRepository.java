package com.gridfolio.app.repositories;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class AuthRepository {
    private final FirebaseAuth auth = FirebaseAuth.getInstance();

    public FirebaseUser currentUser() { return auth.getCurrentUser(); }

    public Task<AuthResult> login(@NonNull String email, @NonNull String pw) {
        return auth.signInWithEmailAndPassword(email, pw);
    }
    public Task<AuthResult> signup(@NonNull String email, @NonNull String pw) {
        return auth.createUserWithEmailAndPassword(email, pw);
    }
    public Task<Void> resetPassword(@NonNull String email) {
        return auth.sendPasswordResetEmail(email);
    }
    public void logout() { auth.signOut(); }
}
