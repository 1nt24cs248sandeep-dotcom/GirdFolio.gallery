package com.gridfolio.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.gridfolio.app.R;
import com.gridfolio.app.models.ImageItem;
import com.gridfolio.app.utils.GlideHelper;

import java.util.ArrayList;
import java.util.List;

public class ImageGridAdapter extends RecyclerView.Adapter<ImageGridAdapter.VH> {

    public interface OnImageClick { void onClick(ImageItem item, int position, View shared); }

    private final List<ImageItem> items = new ArrayList<>();
    private final OnImageClick listener;

    public ImageGridAdapter(OnImageClick l) { this.listener = l; }

    public void submit(List<ImageItem> next) {
        items.clear();
        items.addAll(next);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int v) {
        View view = LayoutInflater.from(p.getContext()).inflate(R.layout.item_image_grid, p, false);
        return new VH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        ImageItem it = items.get(position);
        GlideHelper.load(h.itemView.getContext(), it.storageUrl, h.image);
        h.caption.setText(it.caption == null ? "" : it.caption);
        h.itemView.setOnClickListener(v -> { if (listener != null) listener.onClick(it, position, h.image); });
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        ImageView image; TextView caption;
        VH(@NonNull View v) { super(v);
            image = v.findViewById(R.id.image);
            caption = v.findViewById(R.id.caption);
        }
    }
}
