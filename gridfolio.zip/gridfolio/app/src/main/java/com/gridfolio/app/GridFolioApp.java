package com.gridfolio.app;

import android.app.Application;
import androidx.appcompat.app.AppCompatDelegate;
import android.content.SharedPreferences;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;

public class GridFolioApp extends Application {

    public static final String PREFS = "gridfolio_prefs";
    public static final String KEY_DARK = "dark_mode";
    public static final String KEY_COLUMNS = "grid_columns";
    public static final String KEY_LAYOUT = "layout_type"; // "grid" or "staggered"

    @Override
    public void onCreate() {
        super.onCreate();

        // Enable Firestore offline persistence
        FirebaseFirestoreSettings settings = new FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(true)
                .build();
        FirebaseFirestore.getInstance().setFirestoreSettings(settings);

        // Apply saved dark mode preference
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean dark = prefs.getBoolean(KEY_DARK, false);
        AppCompatDelegate.setDefaultNightMode(
                dark ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        );
    }
}
