package com.gridfolio.app.viewmodels;

import androidx.lifecycle.ViewModel;

public class UploadViewModel extends ViewModel {
    // Holds in-progress upload state; extend as needed.
}
