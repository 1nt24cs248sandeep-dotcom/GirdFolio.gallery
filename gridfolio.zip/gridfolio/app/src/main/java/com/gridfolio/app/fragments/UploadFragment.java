package com.gridfolio.app.fragments;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.gridfolio.app.R;
import com.gridfolio.app.models.ImageItem;
import com.gridfolio.app.repositories.ImageRepository;

import java.util.List;

public class UploadFragment extends Fragment {

    private final ImageRepository repo = new ImageRepository();
    private Uri pickedUri;
    private ProgressBar progress;
    private TextInputEditText captionField;

    private final ActivityResultLauncher<String> picker =
            registerForActivityResult(new ActivityResultContracts.GetMultipleContents(), this::onPicked);

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_upload, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        progress = v.findViewById(R.id.progress);
        captionField = v.findViewById(R.id.field_caption);
        ((MaterialButton) v.findViewById(R.id.btn_pick)).setOnClickListener(b -> picker.launch("image/*"));
        ((MaterialButton) v.findViewById(R.id.btn_upload)).setOnClickListener(b -> upload());
    }

    private void onPicked(List<Uri> uris) {
        if (uris != null && !uris.isEmpty()) pickedUri = uris.get(0);
    }

    private void upload() {
        if (pickedUri == null) {
            Toast.makeText(getContext(), R.string.error_no_image, Toast.LENGTH_SHORT).show();
            return;
        }
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) return;
        progress.setVisibility(View.VISIBLE);
        String fileName = "img_" + System.currentTimeMillis() + ".jpg";
        repo.uploadFile(uid, fileName, pickedUri)
            .continueWithTask(t -> t.getResult().getStorage().getDownloadUrl())
            .addOnSuccessListener(downloadUrl -> {
                ImageItem it = new ImageItem();
                it.userId = uid;
                it.storageUrl = downloadUrl.toString();
                it.caption = String.valueOf(captionField.getText());
                it.createdAt = System.currentTimeMillis();
                it.sortOrder = it.createdAt;
                repo.addMetadata(it).addOnCompleteListener(x -> {
                    progress.setVisibility(View.GONE);
                    Toast.makeText(getContext(), R.string.toast_upload_done, Toast.LENGTH_SHORT).show();
                });
            })
            .addOnFailureListener(e -> {
                progress.setVisibility(View.GONE);
                Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_LONG).show();
            });
    }
}
