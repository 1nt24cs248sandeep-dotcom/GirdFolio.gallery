package com.gridfolio.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            boolean signedIn = FirebaseAuth.getInstance().getCurrentUser() != null;
            Intent i = new Intent(this, signedIn ? MainActivity.class : AuthActivity.class);
            startActivity(i);
            finish();
        }, 1500);
    }
}
