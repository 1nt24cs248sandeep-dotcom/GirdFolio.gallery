package com.gridfolio.app.fragments;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.gridfolio.app.GridFolioApp;
import com.gridfolio.app.R;
import com.gridfolio.app.activities.AuthActivity;

public class ProfileFragment extends Fragment {

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_profile, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        TextView name = v.findViewById(R.id.profile_name);
        TextView email = v.findViewById(R.id.profile_email);
        MaterialSwitch darkSwitch = v.findViewById(R.id.switch_dark);
        MaterialButton logout = v.findViewById(R.id.btn_logout);

        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u != null) {
            name.setText(u.getDisplayName() == null ? u.getEmail() : u.getDisplayName());
            email.setText(u.getEmail());
        }

        SharedPreferences prefs = requireContext().getSharedPreferences(GridFolioApp.PREFS, 0);
        darkSwitch.setChecked(prefs.getBoolean(GridFolioApp.KEY_DARK, false));
        darkSwitch.setOnCheckedChangeListener((b, checked) -> {
            prefs.edit().putBoolean(GridFolioApp.KEY_DARK, checked).apply();
            AppCompatDelegate.setDefaultNightMode(checked
                    ? AppCompatDelegate.MODE_NIGHT_YES
                    : AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        });

        logout.setOnClickListener(b -> {
            FirebaseAuth.getInstance().signOut();
            Intent i = new Intent(getContext(), AuthActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        });
    }
}
