package com.gridfolio.app.models;

import java.util.ArrayList;
import java.util.List;

public class ImageItem {
    public String id;
    public String galleryId;
    public String userId;
    public String storageUrl;
    public String caption;
    public List<String> tags = new ArrayList<>();
    public long sortOrder;
    public long createdAt;

    public ImageItem() {}
}
