package com.gridfolio.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.gridfolio.app.R;
import com.gridfolio.app.utils.ValidationUtils;

public class AuthActivity extends AppCompatActivity {

    private TextInputEditText emailField, passwordField;
    private boolean isLoginMode = true;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);

        auth = FirebaseAuth.getInstance();

        emailField = findViewById(R.id.field_email);
        passwordField = findViewById(R.id.field_password);
        MaterialButton submit = findViewById(R.id.btn_submit);
        MaterialButton toggle = findViewById(R.id.btn_toggle_mode);
        View forgot = findViewById(R.id.btn_forgot);

        submit.setOnClickListener(v -> handleSubmit());
        toggle.setOnClickListener(v -> {
            isLoginMode = !isLoginMode;
            submit.setText(isLoginMode ? R.string.action_login : R.string.action_signup);
            toggle.setText(isLoginMode ? R.string.prompt_create_account : R.string.prompt_have_account);
        });
        forgot.setOnClickListener(v -> handleForgotPassword());
    }

    private void handleSubmit() {
        String email = String.valueOf(emailField.getText()).trim();
        String password = String.valueOf(passwordField.getText());

        if (!ValidationUtils.isValidEmail(email)) {
            Toast.makeText(this, R.string.error_invalid_email, Toast.LENGTH_SHORT).show();
            return;
        }
        if (!ValidationUtils.isValidPassword(password)) {
            Toast.makeText(this, R.string.error_invalid_password, Toast.LENGTH_SHORT).show();
            return;
        }

        if (isLoginMode) {
            auth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener(r -> goHome())
                .addOnFailureListener(e -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show());
        } else {
            auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(r -> goHome())
                .addOnFailureListener(e -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show());
        }
    }

    private void handleForgotPassword() {
        String email = String.valueOf(emailField.getText()).trim();
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, R.string.error_invalid_email, Toast.LENGTH_SHORT).show();
            return;
        }
        auth.sendPasswordResetEmail(email)
            .addOnSuccessListener(v -> Toast.makeText(this, R.string.toast_reset_sent, Toast.LENGTH_SHORT).show())
            .addOnFailureListener(e -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void goHome() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
