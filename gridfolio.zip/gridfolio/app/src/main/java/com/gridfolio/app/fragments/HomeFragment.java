package com.gridfolio.app.fragments;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.gridfolio.app.GridFolioApp;
import com.gridfolio.app.R;
import com.gridfolio.app.adapters.ImageGridAdapter;
import com.gridfolio.app.viewmodels.HomeViewModel;

public class HomeFragment extends Fragment {
    private HomeViewModel vm;
    private ImageGridAdapter adapter;
    private RecyclerView recycler;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle s) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        recycler = v.findViewById(R.id.recycler);
        SwipeRefreshLayout swipe = v.findViewById(R.id.swipe);

        SharedPreferences prefs = requireContext().getSharedPreferences(GridFolioApp.PREFS, 0);
        int columns = prefs.getInt(GridFolioApp.KEY_COLUMNS, 3);
        String layout = prefs.getString(GridFolioApp.KEY_LAYOUT, "grid");

        if ("staggered".equals(layout)) {
            recycler.setLayoutManager(new StaggeredGridLayoutManager(columns, StaggeredGridLayoutManager.VERTICAL));
        } else {
            recycler.setLayoutManager(new GridLayoutManager(getContext(), columns));
        }

        adapter = new ImageGridAdapter((item, pos, shared) -> {
            // TODO: open ImageViewerFragment with shared element transition
        });
        recycler.setAdapter(adapter);

        vm = new ViewModelProvider(this).get(HomeViewModel.class);
        vm.getImages().observe(getViewLifecycleOwner(), list -> {
            adapter.submit(list);
            swipe.setRefreshing(false);
        });
        vm.load();

        swipe.setOnRefreshListener(() -> vm.load());
    }
}
