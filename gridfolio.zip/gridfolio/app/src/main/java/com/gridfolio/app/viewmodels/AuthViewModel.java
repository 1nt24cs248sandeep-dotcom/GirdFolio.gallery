package com.gridfolio.app.viewmodels;

import androidx.lifecycle.ViewModel;
import com.gridfolio.app.repositories.AuthRepository;

public class AuthViewModel extends ViewModel {
    public final AuthRepository repo = new AuthRepository();
}
