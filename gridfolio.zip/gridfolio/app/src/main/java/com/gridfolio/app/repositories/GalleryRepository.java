package com.gridfolio.app.repositories;

import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.Query;
import com.gridfolio.app.models.Gallery;

public class GalleryRepository {
    private final CollectionReference col =
            FirebaseFirestore.getInstance().collection("galleries");

    public Task<DocumentReference> create(Gallery g) { return col.add(g); }
    public Task<Void> delete(String id) { return col.document(id).delete(); }
    public Task<QuerySnapshot> listForUser(String uid) {
        return col.whereEqualTo("userId", uid)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get();
    }
}
